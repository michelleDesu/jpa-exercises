package se.lexicon.michelle.jpaexercises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExercisesApplicationTests {

	@Test
	void contextLoads() {
	}

}
